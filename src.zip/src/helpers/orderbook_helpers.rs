use super::{OrderCancelPayload, OrderCreatePayload, OrderModifyPayload};
use crate::orderbook::manager::BookManager;
use crate::orderbook::manager::BookManagerStd;
use pricelevel::{OrderId, OrderUpdate};
use tracing::{info, warn};

pub fn handle_order_create(manager: &mut BookManagerStd<()>, order: OrderCreatePayload) {
    let symbol = order.instrument_id;
    if manager.get_book(&symbol).is_none() {
        info!("No book for {}, creating one on demand", symbol);
        manager.add_book(&symbol);
    }
    let Some(book) = manager.get_book(&symbol) else {
        warn!("Unable to get book for {} after add_book", symbol);
        return;
    };
    let order_id = OrderId::from_u64(order.order_id);
    if let Err(e) = book.add_limit_order(
        order_id,
        order.price,
        order.quantity,
        order.side,
        order.time_in_force,
        None,
    ) {
        warn!("Failed to add order {} on {}: {}", order_id, symbol, e);
    }
    info!("Added order {} on {}", order_id, symbol);
}

pub fn handle_order_cancel(manager: &mut BookManagerStd<()>, order: OrderCancelPayload) {
    let Some(book) = manager.get_book_mut(&order.instrument_id) else {
        warn!(
            "No book found for {}, cannot cancel order {}",
            order.instrument_id, order.order_id
        );
        return;
    };
    let order_id = OrderId::from_u64(order.order_id);
    if let Err(e) = book.cancel_order(order_id) {
        warn!(
            "Failed to remove order {} on {}: {}",
            order_id, order.instrument_id, e
        );
    }
    info!("Cancelled order {} on {}", order_id, order.instrument_id);
}

pub fn handle_order_modify(manager: &mut BookManagerStd<()>, order: OrderModifyPayload) {
    let Some(book) = manager.get_book_mut(&order.instrument_id) else {
        warn!(
            "No book found for {}, cannot modify order {}",
            order.instrument_id, order.order_id
        );
        return;
    };
    let order_id = OrderId::from_u64(order.order_id);
    let order_update = OrderUpdate::UpdatePriceAndQuantity {
        order_id,
        new_price: order.price,
        new_quantity: order.quantity,
    };
    if let Err(e) = book.update_order(order_update) {
        warn!(
            "Failed to modify order {} on {}: {}",
            order_id, order.instrument_id, e
        );
    }
}